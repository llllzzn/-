package com.hui.constants;


public interface CommonConstants {
        String COMMENT_FAILED = "评论失败";
        String COMMENT_SUCCESS = "评论成功";

}

