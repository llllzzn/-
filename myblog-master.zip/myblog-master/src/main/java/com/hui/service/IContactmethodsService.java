package com.hui.service;

import com.hui.domain.po.Contactmethods;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author hui
 * @since 2024-10-22
 */
public interface IContactmethodsService extends IService<Contactmethods> {

}
